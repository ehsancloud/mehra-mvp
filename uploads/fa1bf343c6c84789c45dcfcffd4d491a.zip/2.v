module binary_to_excess3 (
    input  [3:0] bin,   // ورودی باینری (b3 b2 b1 b0)
    output [3:0] ex3    // خروجی افزونی ۳ (e3 e2 e1 e0)
);


// e0 = NOT b0
not (ex3[0], bin[0]);

// e1 = b1 XOR b0 XOR 1
xor (temp, bin[1], bin[0]);
xor (ex3[1], temp, 1'b1);

// c1 = b1 OR b0
or (c1, bin[1], bin[0]);

// e2 = b2 XOR c1
xor (ex3[2], bin[2], c1);

// c2 = b2 AND c1
and (c2, bin[2], c1);

// e3 = b3 XOR c2
xor (ex3[3], bin[3], c2);

endmodule