import React, { useEffect, useState } from "react";
import UserHeader from "../components/UserHeader";
import ReleasePaymentModal from "../components/ReleasePaymentModal";
import { BiExport } from "react-icons/bi";
import PaymentReceiptModal from "../components/PaymentReceiptModal";
import {
  getFinanceStats,
  getFinanceProjects,
  getCurrentUserId,
  getUserById,
} from "../data/api";
import { useAuthStore } from "../store/authStore";
const formatPrice = (price) => {
  return price ? price.toLocaleString("fa-IR").replace(/٬/g, ",") : "۰";
};

// Presentation (border/badge colors, which buttons show) derived from each
// transaction's `state`, so the backend only ever needs to send that one
// field instead of Tailwind classes.
const TRANSACTION_STATE_STYLES = {
  paid: {
    borderBg: "border-r-[6px] border-r-green-600",
    statusBg: "bg-green-100 text-green-700",
    hasDetailsBtn: true,
    isBlocked: false,
  },
  blocked: {
    borderBg: "border-r-[6px] border-r-red-700",
    statusBg: "bg-red-100 text-red-700",
    hasDetailsBtn: false,
    isBlocked: true,
  },
  pending: {
    borderBg: "border-r-[6px] border-r-amber-700",
    statusBg: "bg-amber-100 text-amber-800",
    hasDetailsBtn: false,
    isBlocked: false,
  },
};

const SupervisorFinance = () => {
  const [projects, setProjects] = useState([]);
  const [stats, setStats] = useState(null);
  const [selectedProject, setSelectedProject] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const [isReceiptModalOpen, setIsReceiptModalOpen] = useState(false);
  const [selectedTxn, setSelectedTxn] = useState(null);

  const { user: currentSupervisor } = useAuthStore();
  useEffect(() => {
    getFinanceStats().then(setStats);
    getFinanceProjects().then((list) => {
      setProjects(list);
      setSelectedProject(list[0] || null);
    });
  }, []);

  return (
    <div
      className="flex h-screen w-full flex-col bg-gray-50 overflow-hidden"
      dir="rtl"
    >
      <header className="w-full flex justify-between items-center px-12 py-6 shrink-0 select-none">
        <h1
          className="text-[32px] font-bold text-[#1c1c1e]"
          style={{ fontFamily: "Pinar-FD" }}
        >
          مدیریت مالی
        </h1>
        <UserHeader userInitial={currentSupervisor?.initial} hasNotification={true} />
      </header>

      <div className="flex-1 w-full overflow-y-auto px-12 pb-12 flex flex-col gap-6 scrollbar-none select-none">
        <div
          className="w-full grid grid-cols-4 gap-4"
          style={{ fontFamily: "Pinar-FD" }}
        >
          <div className="bg-white border-2 border-[#1e40af] rounded-[5px] p-3 shadow-[0_3px_0_0_#1e40af] flex flex-col justify-between h-[80px] text-right">
            <span className="text-[11px] text-gray-500">تعداد پروژه فعال</span>
            <div className="flex items-baseline justify-start gap-1">
              <span className="text-[22px] font-bold text-[#1e40af]">
                {(stats?.activeProjectsCount ?? 0).toLocaleString("fa-IR")}
              </span>
              <span className="text-[10px] text-gray-500">پروژه</span>
            </div>
          </div>

          <div className="bg-white border-2 border-[#1e40af] rounded-[5px] p-3 shadow-[0_3px_0_0_#1e40af] flex flex-col justify-between h-[80px] text-right">
            <span className="text-[11px] text-gray-500">در انتظار تسویه</span>
            <div className="flex items-baseline justify-start gap-1">
              <span className="text-[20px] font-bold text-[#1e40af]">
                {formatPrice(stats?.awaitingSettlement)}
              </span>
              <span className="text-[10px] text-gray-500">تومان</span>
            </div>
          </div>

          <div className="bg-white border-2 border-[#1e40af] rounded-[5px] p-3 shadow-[0_3px_0_0_#1e40af] flex flex-col justify-between h-[80px] text-right">
            <span className="text-[11px] text-gray-500">آزادسازی این ماه</span>
            <div className="flex items-baseline justify-start gap-1">
              <span className="text-[20px] font-bold text-[#1e40af]">
                {formatPrice(stats?.releasedThisMonth)}
              </span>
              <span className="text-[10px] text-gray-500">تومان</span>
            </div>
          </div>

          <div className="bg-white border-2 border-[#1e40af] rounded-[5px] p-3 shadow-[0_3px_0_0_#1e40af] flex flex-col justify-between h-[80px] text-right">
            <span className="text-[11px] text-gray-500">
              مجموع پول بلاک شده
            </span>
            <div className="flex items-baseline justify-start gap-1">
              <span className="text-[20px] font-bold text-[#1e40af]">
                {formatPrice(stats?.totalBlocked)}
              </span>
              <span className="text-[10px] text-gray-500">تومان</span>
            </div>
          </div>
        </div>

        <div className="w-full flex gap-6 items-start">
          <div
            className="flex-1 bg-white border border-black rounded-[5px] shadow-[0_4px_0_0_#000000] overflow-hidden"
            style={{ fontFamily: "Pinar-FD" }}
          >
            <div className="bg-[#e1effe] p-2.5 border-b border-black text-right text-[12px] font-bold text-[#1e40af]">
              لیست پروژه ها
            </div>

            <div className="grid grid-cols-5 p-3 bg-gray-100/70 border-b border-gray-200 text-[11px] font-bold text-gray-500 items-center">
              <div className="text-right pr-4">عنوان پروژه</div>
              <div className="text-center">تاریخ</div>
              <div className="text-center">مبلغ کل</div>
              <div className="text-center">بلاک شده</div>
              <div className="text-center">آزادسازی</div>
            </div>

            <div className="flex flex-col">
              {projects.map((proj) => (
                <div
                  key={proj.id}
                  onClick={() => setSelectedProject(proj)}
                  className={`grid grid-cols-5 p-3.5 border-b border-gray-200 text-[12px] items-center cursor-pointer transition-all
                    ${selectedProject?.id === proj.id ? "bg-blue-50/80 font-bold border-l-4 border-l-[#3b82f6]" : "hover:bg-gray-50"}
                  `}
                >
                  <div className="text-right pr-4 font-bold text-black">
                    {proj.title}
                  </div>

                  <div className="text-center text-gray-500 text-[11px]">
                    {proj.date}
                  </div>

                  <div className="text-center text-black font-medium">
                    {formatPrice(proj.totalAmount)} ت
                  </div>

                  <div className="text-center text-red-700 font-bold">
                    {proj.blockedAmount > 0
                      ? `${formatPrice(proj.blockedAmount)} ت`
                      : "—"}
                  </div>

                  <div className="flex justify-center">
                    {proj.statusType === "جزئی" && (
                      <span className="bg-[#fef3c7] text-[#92400e] px-3 py-0.5 rounded-[4px] text-[10px] font-bold">
                        جزئی
                      </span>
                    )}
                    {proj.statusType === "بلاک" && (
                      <span className="bg-[#fee2e2] text-[#991b1b] px-3 py-0.5 rounded-[4px] text-[10px] font-bold">
                        بلاک
                      </span>
                    )}
                    {proj.statusType === "کامل" && (
                      <span className="bg-[#dcfce7] text-[#166534] px-3 py-0.5 rounded-[4px] text-[10px] font-bold">
                        کامل
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div
            className="w-[380px] bg-white border border-black rounded-[5px] shadow-[0_4px_0_0_#000000] p-4 flex flex-col gap-4 shrink-0"
            style={{ fontFamily: "Pinar-FD" }}
          >
            <div className="w-full bg-[#e1effe] border border-blue-200 rounded-[4px] p-2 text-center text-[12px] font-bold text-[#1e40af]">
              {selectedProject ? selectedProject.title : "انتخاب پروژه"}
            </div>

            <div className="flex flex-col gap-3 min-h-[220px]">
              {selectedProject?.transactions &&
              selectedProject.transactions.length > 0 ? (
                selectedProject.transactions.map((tx) => {
                  const style =
                    TRANSACTION_STATE_STYLES[tx.state] ||
                    TRANSACTION_STATE_STYLES.pending;
                  return (
                    <div
                      key={tx.id}
                      className={`w-full bg-white border border-gray-300 rounded-[5px] p-3 shadow-sm flex flex-col gap-2 relative ${style.borderBg}`}
                    >
                      <div className="flex justify-between items-center">
                        <span
                          className={`px-2.5 py-0.5 rounded-[4px] text-[10px] font-bold ${style.statusBg}`}
                        >
                          {tx.status}
                        </span>
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] text-gray-400">
                            {tx.date}
                          </span>
                          <span className="text-[14px] font-bold text-black">
                            {formatPrice(tx.amount)} ت
                          </span>
                        </div>
                      </div>

                      <div className="flex justify-between items-center text-[11px] text-gray-600 mt-1">
                        {style.hasDetailsBtn && (
                          <button
                            onClick={() => {
                              setSelectedTxn({
                                ...tx,
                                projectName: selectedProject.title,
                              });
                              setIsReceiptModalOpen(true);
                            }}
                            className="h-[24px] px-2.5 bg-[#1c1c1e] text-white rounded-[4px] text-[10px] font-bold flex items-center gap-1 cursor-pointer hover:bg-zinc-700"
                          >
                            جزئیات <BiExport className="text-xs" />
                          </button>
                        )}

                        {style.isBlocked && (
                          <button
                            onClick={() => setIsModalOpen(true)}
                            className="h-[24px] px-3 bg-[#166534] text-white rounded-[4px] text-[10px] font-bold cursor-pointer shadow-sm active:translate-y-[1px]"
                          >
                            پرداخت / آزادسازی
                          </button>
                        )}

                        <span className="mr-auto text-[10px]">← {tx.target}</span>
                      </div>
                    </div>
                  );
                })
              ) : (
                <div className="text-center text-gray-400 text-[12px] my-auto">
                  تراکنشی برای این پروژه یافت نشد.
                </div>
              )}
            </div>

            <div className="w-full border-t border-gray-200 pt-3 flex justify-between items-center text-[14px] font-bold text-black">
              <span>{formatPrice(selectedProject?.totalAmount)} تومان</span>
              <span className="text-gray-500 text-[12px]">مبلغ کل:</span>
            </div>
          </div>
        </div>
      </div>

      <ReleasePaymentModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        project={selectedProject}
        onReleased={(updatedProject) => {
          setSelectedProject(updatedProject);
          setProjects((prev) =>
            prev.map((p) => (p.id === updatedProject.id ? updatedProject : p)),
          );
        }}
      />

      <PaymentReceiptModal
        isOpen={isReceiptModalOpen}
        onClose={() => setIsReceiptModalOpen(false)}
        txData={selectedTxn}
      />
    </div>
  );
};

export default SupervisorFinance;
