import React, { useEffect, useState } from "react";
import { BiBell } from "react-icons/bi";
import { useAuthStore } from "../store/authStore";
import { getNotifications, markNotificationAsRead, logout as apiLogout } from "../data/api";

const UserHeader = () => {
  const { user, logout: storeLogout } = useAuthStore();
  const [notifications, setNotifications] = useState([]);
  const [showNotifs, setShowNotifs] = useState(false);

  useEffect(() => {
    if (user) {
      getNotifications().then(setNotifications);
    }
  }, [user]);

  const handleRead = async (id) => {
    await markNotificationAsRead(id);
    setNotifications((prev) => prev.filter((n) => n._id !== id));
  };

  const handleLogout = () => {
    storeLogout();
    apiLogout();
  };

  return (
    <div className="flex items-center gap-4 relative" dir="rtl" style={{ fontFamily: "Pinar-FD" }}>
      {/* زنگوله اعلانات */}
      <div className="relative">
        <button
          type="button"
          onClick={() => setShowNotifs(!showNotifs)}
          className="w-9 h-9 rounded-full bg-white border border-black flex items-center justify-center text-lg shadow-[0_2px_0_0_#000000] cursor-pointer"
        >
          <BiBell />
          {notifications.length > 0 && (
            <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-600 text-white rounded-full text-[10px] flex items-center justify-center font-bold">
              {notifications.length}
            </span>
          )}
        </button>

        {/* لیست دراپ‌داون نوتیفیکیشن‌ها */}
        {showNotifs && (
          <div className="absolute left-0 mt-2 w-72 bg-white border border-black rounded-[6px] shadow-[0_4px_0_0_#000000] p-3 z-50 flex flex-col gap-2">
            <h4 className="text-[12px] font-bold text-black border-b pb-1">اعلانات جدید</h4>
            {notifications.length > 0 ? (
              notifications.map((n) => (
                <div
                  key={n._id}
                  onClick={() => handleRead(n._id)}
                  className="p-2 bg-gray-50 hover:bg-gray-100 rounded cursor-pointer text-right border"
                >
                  <span className="block text-[11px] font-bold text-black">{n.title}</span>
                  <p className="text-[10px] text-gray-600 mt-0.5">{n.text}</p>
                </div>
              ))
            ) : (
              <span className="text-[11px] text-gray-400 text-center py-2">اعلان جدیدی ندارید</span>
            )}
          </div>
        )}
      </div>

      {/* آواتار کاربر و خروج */}
      <div className="flex items-center gap-2">
        <div className="w-9 h-9 rounded-full bg-[#1c1c1e] text-white flex items-center justify-center font-bold text-[14px]">
          {user?.initial || "U"}
        </div>
        <button
          type="button"
          onClick={handleLogout}
          className="text-[11px] text-red-600 font-bold hover:underline cursor-pointer"
        >
          خروج
        </button>
      </div>
    </div>
  );
};

export default UserHeader;