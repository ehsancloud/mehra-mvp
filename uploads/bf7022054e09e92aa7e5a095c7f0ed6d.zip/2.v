module testbranch;

reg [3:0] A;
wire F;
integer i;

my_detector uut(.A(A), .F(F));

initial begin
    for (i = 0; i < 16; i = i + 1) begin
        A = i;
        #10;
        $display("A=%d F=%b", A, F);
    end
end

endmodule