module my_detector(
    input [3:0] A,
    output F
);

assign F = (~A[3] & ~A[2] & A[1]) | (~A[2] & A[1] & A[0]) | (A[2] & ~A[1] & A[0]) | (~A[3] & A[2] & A[0]);

endmodule